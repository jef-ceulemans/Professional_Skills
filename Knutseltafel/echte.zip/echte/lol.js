let img = document.querySelector('img');
let btn1 = document.querySelector('#btn1');
let btn2 = document.querySelector('#btn2');
let btn3 = document.querySelector('#btn3');
let btn4 = document.querySelector('#btn4');
let btn5 = document.querySelector('#btn5');
let btn6 = document.querySelector('#btn6');
let btn7 = document.querySelector('#btn7');

btn1.addEventListener('click', () => {
    img.src =  'images/oef.png'
})


btn2.addEventListener('click', () => {
    img.src =  'images/oef3.png'
})


btn3.addEventListener('click', () => {
    img.src =  'images/oef3.png'
})
